#ifndef LIBRARY_H
#define LIBRARY_H

#include "song.h"

struct SongLibrary {
    struct Song *head;
};

struct SongLibrary *create_library();
void add_to_library(struct SongLibrary *lib, int id, char name[100], char singer[100]);
void display_library(struct SongLibrary *lib);
struct Song *find_song_in_library(struct SongLibrary *lib, int id);
struct Song *search_library_by_name(struct SongLibrary *lib, char name[100]);
void search_and_display_library(struct SongLibrary *lib, char keyword[100]);
void add_user_song_to_library(struct SongLibrary *lib, char name[100], char singer[100]);
void save_library(struct SongLibrary *lib);
struct SongLibrary *load_library();
void free_library(struct SongLibrary *lib);

#endif