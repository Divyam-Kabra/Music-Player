#ifndef PLAYLIST_H
#define PLAYLIST_H

#include "song.h"

struct Playlist {
    int id;
    char name[100];
    struct Song *head;
    struct Playlist *next;
};

struct Playlist *create_playlist(struct Playlist *plist, char name[100]);
struct Playlist *find_playlist(struct Playlist *plist, char name[100]);
struct Playlist *find_playlist_by_id(struct Playlist *plist, int id);
void display_playlists(struct Playlist *plist);
void free_playlist(struct Song *head);
void save_playlist(struct Playlist *head);
struct Playlist *load_playlists();

#endif