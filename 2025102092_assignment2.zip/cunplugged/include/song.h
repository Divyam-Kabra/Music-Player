#ifndef SONG_H
#define SONG_H

struct Song {
    int id;
    char name[100];
    char singer[100];
    struct Song *next;
    struct Song *prev;
};

struct Song *create_song(char name[100], char singer[100]);
struct Song *create_library_song(int id, char name[100], char singer[100]);
struct Song *insertatend(struct Song *head, char name[100], char singer[100]);
struct Song *add_song_from_library(struct Song *head, struct Song *library_song);
struct Song *deletesong_by_id(struct Song *head, int id);
struct Song *deletesong(struct Song *head, char name[100]);
void displaysongs(struct Song *head);
void play(struct Song *head);

#endif