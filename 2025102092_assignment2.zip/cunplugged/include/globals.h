#ifndef GLOBALS_H
#define GLOBALS_H

extern int next_song_id;
extern int next_playlist_id;
extern int next_library_song_id;

#endif