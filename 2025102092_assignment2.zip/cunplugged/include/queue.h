#ifndef QUEUE_H
#define QUEUE_H

#include "song.h"

struct SongQueue {
    struct Song *front, *rear;
};

struct SongQueue *create_queue();
void enqueue(struct SongQueue *q, char name[100], char singer[100]);
void play_queue(struct SongQueue *q);

#endif