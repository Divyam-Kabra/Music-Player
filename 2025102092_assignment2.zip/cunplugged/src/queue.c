#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue.h"
#include "song.h"

struct SongQueue *create_queue() {
    struct SongQueue *q = (struct SongQueue *) malloc(sizeof(struct SongQueue));
    q->front = q->rear = NULL;
    return q;
}

void enqueue(struct SongQueue *q, char name[100], char singer[100]) {
    struct Song *song = create_song(name, singer);
    if (q->rear == NULL) {
        q->front = q->rear = song;
        return;
    }
    q->rear->next = song;
    song->prev = q->rear;
    q->rear = song;
}

void play_queue(struct SongQueue *q) {
    if (q->front == NULL) {
        printf("Queue is empty.\n");
        return;
    }
    struct Song *temp = q->front;
    char command[10];
    printf("PLAYING SONG QUEUE (bidirectional)...\n");
    while (1) {
        printf("\nNow playing: [ID: %d] %s by %s\n", temp->id, temp->name, temp->singer);
        printf("Enter 'next', 'prev', or 'quit': ");
        scanf("%s", command);
        if (strcmp(command, "quit") == 0)
            break;
        else if (strcmp(command, "next") == 0) {
            if (temp->next != NULL)
                temp = temp->next;
            else
                printf("This is the last song in queue.\n");
        } else if (strcmp(command, "prev") == 0) {
            if (temp->prev != NULL)
                temp = temp->prev;
            else
                printf("This is the first song in queue.\n");
        } else {
            printf("Invalid command.\n");
        }
    }
}