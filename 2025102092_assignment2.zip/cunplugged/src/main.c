#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "playlist.h"
#include "queue.h"
#include "library.h"
#include "globals.h"

int main() {
    struct Playlist *allPlaylists = NULL;
    struct Playlist *current = NULL;
    struct SongQueue *queue = create_queue();
    struct SongLibrary *library = load_library(); // Load library at startup

    int choice;
    char name[100], singer[100], playlistName[100];
    int search_id;

    FILE *ptr = fopen("logcommand.txt", "a");
    fprintf(ptr, "WELCOME AGAIN!\n");

    do {
        printf("\n===== MUSIC PLAYER MENU =====\n");
        printf("1. Load Playlists\n");
        printf("2. Display All Playlists\n");
        printf("3. Create Playlist\n");
        printf("4. Select Playlist (by name)\n");
        printf("5. Select Playlist (by ID)\n");
        printf("6. Display Current Playlist\n");
        printf("7. Add Song to Current Playlist (manual entry)\n");
        printf("8. Add Song from Library to Current Playlist\n");
        printf("9. Delete Song from Current Playlist (by name)\n");
        printf("10. Delete Song from Current Playlist (by ID)\n");
        printf("11. Play Current Playlist\n");
        printf("12. Add Song to Queue\n");
        printf("13. Play Song Queue\n");
        printf("14. Browse Song Library\n");
        printf("15. Search Song Library\n");
        printf("16. Add Your Own Song to Library\n");
        printf("17. Save Library\n");
        printf("18. Save Playlists\n");
        printf("19. Clear your previous activities\n");
        printf("20. Exit\n");
        printf("Enter your choice(1-20): ");
        scanf("%d", &choice);
        getchar();

        if (choice == 1) {
            allPlaylists = load_playlists();
            current = NULL;
            fprintf(ptr, "Loaded playlists\n");
        } else if (choice == 2) {
            display_playlists(allPlaylists);
            fprintf(ptr, "Displayed playlists\n");
        } else if (choice == 3) {
            printf("Enter new playlist name: ");
            fgets(playlistName, sizeof(playlistName), stdin);
            playlistName[strcspn(playlistName, "\n")] = '\0';
            allPlaylists = create_playlist(allPlaylists, playlistName);
            printf("Playlist '%s' created successfully with ID %d!\n", playlistName, next_playlist_id - 1);
            fprintf(ptr, "Playlist %s created successfully!\n", playlistName);
        } else if (choice == 4) {
            printf("Enter playlist name to select: ");
            fgets(playlistName, sizeof(playlistName), stdin);
            playlistName[strcspn(playlistName, "\n")] = '\0';
            current = find_playlist(allPlaylists, playlistName);
            if (current) {
                printf("Playlist '%s' (ID: %d) selected.\n", playlistName, current->id);
                fprintf(ptr, "Selected playlist: %s\n", playlistName);
            } else {
                printf("Playlist not found.\n");
                fprintf(ptr, "Playlist not found!\n");
            }
        } else if (choice == 5) {
            printf("Enter playlist ID to select: ");
            scanf("%d", &search_id);
            getchar();
            current = find_playlist_by_id(allPlaylists, search_id);
            if (current) {
                printf("Playlist '%s' (ID: %d) selected.\n", current->name, current->id);
                fprintf(ptr, "Selected playlist by ID: %d\n", search_id);
            } else {
                printf("Playlist with ID %d not found.\n", search_id);
                fprintf(ptr, "Playlist ID not found!\n");
            }
        } else if (choice == 6) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else {
                displaysongs(current->head);
                fprintf(ptr, "Displayed playlist: %s\n", current->name);
            }
        } else if (choice == 7) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else {
                printf("Enter song name: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = '\0';
                printf("Enter singer name: ");
                fgets(singer, sizeof(singer), stdin);
                singer[strcspn(singer, "\n")] = '\0';
                current->head = insertatend(current->head, name, singer);
                printf("Song added successfully with ID %d!\n", next_song_id - 1);
                fprintf(ptr, "Added song: %s by %s\n", name, singer);
            }
        } else if (choice == 8) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else {
                printf("Enter song ID from library to add: ");
                scanf("%d", &search_id);
                getchar();

                struct Song *lib_song = find_song_in_library(library, search_id);
                if (lib_song != NULL) {
                    current->head = add_song_from_library(current->head, lib_song);
                    printf("Song '%s' by %s added to playlist!\n", lib_song->name, lib_song->singer);
                    fprintf(ptr, "Added from library: %s by %s\n", lib_song->name, lib_song->singer);
                } else {
                    printf("Song with ID %d not found in library.\n", search_id);
                }
            }
        } else if (choice == 9) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else if (current->head == NULL) {
                printf("No songs in the playlist to be deleted\n");
            } else {
                printf("Enter the song name to delete: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = '\0';
                current->head = deletesong(current->head, name);
                fprintf(ptr, "Deleted song: %s\n", name);
            }
        } else if (choice == 10) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else if (current->head == NULL) {
                printf("No songs in the playlist to be deleted\n");
            } else {
                printf("Enter the song ID to delete: ");
                scanf("%d", &search_id);
                getchar();
                current->head = deletesong_by_id(current->head, search_id);
                fprintf(ptr, "Deleted song by ID: %d\n", search_id);
            }
        } else if (choice == 11) {
            if (current == NULL) {
                printf("No playlist selected.\n");
            } else {
                play(current->head);
                fprintf(ptr, "Played playlist: %s\n", current->name);
            }
        } else if (choice == 12) {
            printf("Enter song name for queue: ");
            fgets(name, sizeof(name), stdin);
            name[strcspn(name, "\n")] = '\0';
            printf("Enter singer name: ");
            fgets(singer, sizeof(singer), stdin);
            singer[strcspn(singer, "\n")] = '\0';
            enqueue(queue, name, singer);
            printf("Song added to queue.\n");
            fprintf(ptr, "Added to queue: %s by %s\n", name, singer);
        } else if (choice == 13) {
            play_queue(queue);
            fprintf(ptr, "Played song queue\n");
        } else if (choice == 14) {
            display_library(library);
            fprintf(ptr, "Browsed song library\n");
        } else if (choice == 15) {
            printf("Enter song name or artist to search: ");
            fgets(name, sizeof(name), stdin);
            name[strcspn(name, "\n")] = '\0';
            search_and_display_library(library, name);
            fprintf(ptr, "Searched library for: %s\n", name);
        } else if (choice == 16) {
            printf("Enter song name to add to library: ");
            fgets(name, sizeof(name), stdin);
            name[strcspn(name, "\n")] = '\0';
            printf("Enter singer name: ");
            fgets(singer, sizeof(singer), stdin);
            singer[strcspn(singer, "\n")] = '\0';
            add_user_song_to_library(library, name, singer);
            fprintf(ptr, "Added to library: %s by %s\n", name, singer);
        } else if (choice == 17) {
            save_library(library);
            fprintf(ptr, "Saved song library\n");
        } else if (choice == 18) {
            save_playlist(allPlaylists);
            fprintf(ptr, "Saved playlists\n");
        } else if (choice == 19) {
            FILE *clear = fopen("logcommand.txt", "w");
            if (clear != NULL) {
                fclose(clear);
                printf("Command log cleared\nThank You!.\n");
            } else {
                printf("Error clearing command log.\n");
            }
        } else if (choice == 20) {
            printf("...Exiting music player...\n");
            fprintf(ptr, "Exit the music player!\n");
        } else {
            printf("Invalid choice. Try again.\n");
        }
    } while (choice != 20);

    // Free all playlists
    struct Playlist *temp = allPlaylists;
    while (temp != NULL) {
        free_playlist(temp->head);
        struct Playlist *toFree = temp;
        temp = temp->next;
        free(toFree);
    }

    // Free queue
    struct Song *tempq;
    while (queue->front != NULL) {
        tempq = queue->front;
        queue->front = queue->front->next;
        free(tempq);
    }
    free(queue);

    // Free library
    free_library(library);

    fclose(ptr);
    return 0;
}