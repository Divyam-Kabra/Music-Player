#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "playlist.h"
#include "globals.h"

// Global counter for playlists
int next_playlist_id = 1;

struct Playlist *create_playlist(struct Playlist *plist, char name[100]) {
    struct Playlist *newList = (struct Playlist *) malloc(sizeof(struct Playlist));
    newList->id = next_playlist_id++;
    strcpy(newList->name, name);
    newList->head = NULL;
    newList->next = NULL;
    if (plist == NULL)
        return newList;
    struct Playlist *temp = plist;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newList;
    return plist;
}

struct Playlist *find_playlist(struct Playlist *plist, char name[100]) {
    struct Playlist *temp = plist;
    while (temp != NULL) {
        if (strcmp(temp->name, name) == 0)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

struct Playlist *find_playlist_by_id(struct Playlist *plist, int id) {
    struct Playlist *temp = plist;
    while (temp != NULL) {
        if (temp->id == id)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

void display_playlists(struct Playlist *plist) {
    if (plist == NULL) {
        printf("No playlists created yet.\n");
        return;
    }
    struct Playlist *temp = plist;
    printf("\n Available Playlists: \n");
    while (temp != NULL) {
        printf("ID: %d | %s\n", temp->id, temp->name);
        temp = temp->next;
    }
}

void free_playlist(struct Song *head) {
    struct Song *temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }
}

void save_playlist(struct Playlist *head) {
    FILE *ptr = fopen("playlists.txt", "w");
    if (ptr == NULL) {
        printf("ERROR SAVING PLAYLIST\n");
        return;
    }
    struct Playlist *temp = head;
    while (temp != NULL) {
        fprintf(ptr, "#PLAYLIST_ID %d\n", temp->id);
        fprintf(ptr, "#PLAYLIST_NAME %s\n", temp->name);
        struct Song *m = temp->head;
        while (m != NULL) {
            fprintf(ptr, "SONG_ID %d\n", m->id);
            fprintf(ptr, "SONG_NAME %s\n", m->name);
            fprintf(ptr, "SINGER %s\n", m->singer);
            m = m->next;
        }
        fprintf(ptr, "#END\n");
        temp = temp->next;
    }
    fclose(ptr);
    printf("Playlists successfully saved\n");
}

struct Playlist *load_playlists() {
    FILE *file = fopen("playlists.txt", "r");
    if (file == NULL) {
        printf("No saved playlists found.\n");
        return NULL;
    }
    struct Playlist *plist = NULL;
    struct Playlist *current = NULL;
    char line[256];

    int temp_pid = 0, temp_sid = 0;
    char temp_pname[100] = "", temp_sname[100] = "", temp_singer[100] = "";

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0';

        if (strncmp(line, "#PLAYLIST_ID ", 13) == 0) {
            sscanf(line + 13, "%d", &temp_pid);
        } else if (strncmp(line, "#PLAYLIST_NAME ", 15) == 0) {
            strcpy(temp_pname, line + 15);

            // Create playlist
            struct Playlist *newList = (struct Playlist *) malloc(sizeof(struct Playlist));
            newList->id = temp_pid;
            strcpy(newList->name, temp_pname);
            newList->head = NULL;
            newList->next = NULL;

            if (plist == NULL)
                plist = newList;
            else {
                struct Playlist *temp = plist;
                while (temp->next != NULL)
                    temp = temp->next;
                temp->next = newList;
            }
            current = newList;

            if (temp_pid >= next_playlist_id)
                next_playlist_id = temp_pid + 1;

        } else if (strncmp(line, "SONG_ID ", 8) == 0 && current != NULL) {
            sscanf(line + 8, "%d", &temp_sid);
        } else if (strncmp(line, "SONG_NAME ", 10) == 0 && current != NULL) {
            strcpy(temp_sname, line + 10);
        } else if (strncmp(line, "SINGER ", 7) == 0 && current != NULL) {
            strcpy(temp_singer, line + 7);

            // Create song with all info
            struct Song *song = (struct Song *) malloc(sizeof(struct Song));
            song->id = temp_sid;
            strcpy(song->name, temp_sname);
            strcpy(song->singer, temp_singer);
            song->next = NULL;
            song->prev = NULL;

            if (current->head == NULL) {
                current->head = song;
            } else {
                struct Song *temp = current->head;
                while (temp->next != NULL)
                    temp = temp->next;
                temp->next = song;
                song->prev = temp;
            }

            if (temp_sid >= next_song_id)
                next_song_id = temp_sid + 1;

        } else if (strcmp(line, "#END") == 0) {
            current = NULL;
        }
    }
    fclose(file);
    printf("Playlists loaded successfully!\n");
    return plist;
}