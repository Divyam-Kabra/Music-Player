#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "song.h"
#include "globals.h"

// Global counter
int next_song_id = 1;

struct Song *create_song(char name[100], char singer[100]) {
    struct Song *song = (struct Song *) malloc(sizeof(struct Song));
    if (song == NULL) {
        printf("Could not add new song\n");
        return NULL;
    }
    song->id = next_song_id++;
    strcpy(song->name, name);
    strcpy(song->singer, singer);
    song->next = NULL;
    song->prev = NULL;
    return song;
}

struct Song *create_library_song(int id, char name[100], char singer[100]) {
    struct Song *song = (struct Song *) malloc(sizeof(struct Song));
    if (song == NULL) {
        printf("Could not add new song\n");
        return NULL;
    }
    song->id = id;
    strcpy(song->name, name);
    strcpy(song->singer, singer);
    song->next = NULL;
    song->prev = NULL;
    return song;
}

struct Song *insertatend(struct Song *head, char name[100], char singer[100]) {
    struct Song *songadded = create_song(name, singer);
    if (head == NULL) {
        return songadded;
    }
    struct Song *temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = songadded;
    songadded->prev = temp;
    return head;
}

// Add song from library to playlist
struct Song *add_song_from_library(struct Song *head, struct Song *library_song) {
    struct Song *songadded = create_song(library_song->name, library_song->singer);
    if (head == NULL) {
        return songadded;
    }
    struct Song *temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = songadded;
    songadded->prev = temp;
    return head;
}

struct Song *deletesong_by_id(struct Song *head, int id) {
    if (head == NULL) {
        printf("No songs in the playlist to be deleted\n");
        return head;
    }

    struct Song *temp = head;

    if (temp->id == id) {
        head = temp->next;
        if (head != NULL)
            head->prev = NULL;
        free(temp);
        printf("Song deleted successfully!\n");
        return head;
    }

    while (temp != NULL && temp->id != id) {
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Song with ID %d not found in playlist.\n", id);
        return head;
    }

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    free(temp);
    printf("Song deleted successfully!\n");
    return head;
}

struct Song *deletesong(struct Song *head, char name[100]) {
    if (head == NULL) {
        printf("No songs in the playlist to be deleted\n");
        return head;
    }
    struct Song *temp = head;
    struct Song *prev = NULL;
    if (strcmp(temp->name, name) == 0) {
        head = temp->next;
        if (head != NULL)
            head->prev = NULL;
        free(temp);
        printf("Song deleted successfully!\n");
        return head;
    }
    while (temp != NULL && strcmp(temp->name, name) != 0) {
        prev = temp;
        temp = temp->next;
    }
    if (temp == NULL) {
        printf("Song not found in playlist.\n");
        return head;
    }
    prev->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = prev;
    free(temp);
    printf("Song deleted successfully!\n");
    return head;
}

void displaysongs(struct Song *head) {
    if (head == NULL) {
        printf("No songs in playlist.\n");
        return;
    }
    struct Song *temp = head;
    printf("\n--- Playlist Songs ---\n");
    while (temp != NULL) {
        printf("ID: %d | %s by %s\n", temp->id, temp->name, temp->singer);
        temp = temp->next;
    }
}

void play(struct Song *head) {
    if (head == NULL) {
        printf("No songs in the playlist\n");
        return;
    }
    printf("PLAYING SONGS IN YOUR PLAYLIST\n");
    struct Song *ptr = head;
    struct Song *prev = NULL;
    char command[10];
    while (1) {
        printf("Currently playing: [ID: %d] %s by %s\n", ptr->id, ptr->name, ptr->singer);
        printf("Enter 'next' for next song, 'prev' for previous, or 'quit' to stop: ");
        scanf("%s", command);
        if (strcmp(command, "quit") == 0)
            break;
        else if (strcmp(command, "next") == 0) {
            prev = ptr;
            ptr = ptr->next;
            if (ptr == NULL)
                ptr = head;
        } else if (strcmp(command, "prev") == 0) {
            if (ptr->prev != NULL)
                ptr = ptr->prev;
            else {
                while (ptr->next != NULL)
                    ptr = ptr->next;
            }
        } else {
            printf("Invalid command.\n");
        }
    }
}