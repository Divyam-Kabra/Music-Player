#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "library.h"
#include "song.h"
#include "globals.h"

// Global counter for library song IDs
int next_library_song_id = 1;

struct SongLibrary *create_library() {
    struct SongLibrary *lib = (struct SongLibrary *) malloc(sizeof(struct SongLibrary));
    lib->head = NULL;
    return lib;
}

void add_to_library(struct SongLibrary *lib, int id, char name[100], char singer[100]) {
    struct Song *song = create_library_song(id, name, singer);
    if (lib->head == NULL) {
        lib->head = song;
        return;
    }
    struct Song *temp = lib->head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = song;
    song->prev = temp;
}

void display_library(struct SongLibrary *lib) {
    if (lib->head == NULL) {
        printf("Library is empty.\n");
        return;
    }
    printf("\n========== SONG LIBRARY ==========\n");
    struct Song *temp = lib->head;
    while (temp != NULL) {
        printf("ID: %d | %s by %s\n", temp->id, temp->name, temp->singer);
        temp = temp->next;
    }
    printf("-------------\n");
}

struct Song *find_song_in_library(struct SongLibrary *lib, int id) {
    struct Song *temp = lib->head;
    while (temp != NULL) {
        if (temp->id == id)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

struct Song *search_library_by_name(struct SongLibrary *lib, char name[100]) {
    struct Song *temp = lib->head;
    while (temp != NULL) {
        if (strstr(temp->name, name) != NULL || strstr(temp->singer, name) != NULL)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

void search_and_display_library(struct SongLibrary *lib, char keyword[100]) {
    if (lib->head == NULL) {
        printf("Library is empty.\n");
        return;
    }

    printf("\n--- Search Results for '%s' ---\n", keyword);
    struct Song *temp = lib->head;
    int found = 0;

    while (temp != NULL) {
        if (strstr(temp->name, keyword) != NULL || strstr(temp->singer, keyword) != NULL) {
            printf("ID: %d | %s by %s\n", temp->id, temp->name, temp->singer);
            found = 1;
        }
        temp = temp->next;
    }

    if (!found) {
        printf("No songs found matching '%s'\n", keyword);
    }
}

void add_user_song_to_library(struct SongLibrary *lib, char name[100], char singer[100]) {
    int new_id = next_library_song_id++;
    add_to_library(lib, new_id, name, singer);
    printf("Song added to library with ID: %d\n", new_id);
}

void save_library(struct SongLibrary *lib) {
    FILE *file = fopen("song_library.txt", "w");
    if (file == NULL) {
        printf("Error saving library.\n");
        return;
    }

    struct Song *temp = lib->head;
    while (temp != NULL) {
        fprintf(file, "ID %d\n", temp->id);
        fprintf(file, "NAME %s\n", temp->name);
        fprintf(file, "SINGER %s\n", temp->singer);
        temp = temp->next;
    }

    fclose(file);
    printf("Song library saved successfully!\n");
}

struct SongLibrary *load_library() {
    FILE *file = fopen("song_library.txt", "r");
    if (file == NULL) {
        printf("Creating default song library\n");

        // Create default library file
        file = fopen("song_library.txt", "w");
        if (file == NULL) {
            printf("Error creating library file.\n");
            return create_library();
        }

        // Add some default songs
        fprintf(file, "ID 1\nNAME Shape of You\nSINGER Ed Sheeran\n");
        fprintf(file, "ID 2\nNAME Blinding Lights\nSINGER The Weeknd\n");
        fprintf(file, "ID 3\nNAME Baby\nSINGER Justin Bieber\n");
        fprintf(file, "ID 4\nNAME Hall of Fame\nSINGER The Script\n");
        fprintf(file, "ID 5\nNAME No time to Die\nSINGER Billie Ellish\n");
        fprintf(file, "ID 6\nNAME Believer\nSINGER John Lennon\n");
        fprintf(file, "ID 7\nNAME Billie Jean\nSINGER Michael Jackson\n");
        fprintf(file, "ID 8\nNAME Wonderwall\nSINGER Oasis\n");
        fprintf(file, "ID 9\nNAME Rolling in the Deep\nSINGER Adele\n");
        fprintf(file, "ID 10\nNAME Sweet Child O' Mine\nSINGER Guns N' Roses\n");
        fprintf(file, "ID 11\nNAME Wavy\nSINGER Karan Aujla\n");
        fprintf(file, "ID 12\nNAME Ikky\nSINGER Karan Aujla\n");
        fprintf(file, "ID 13\nNAME Tere liye\nSINGER Atif Aslam\n");
        fprintf(file, "ID 14\nNAME Let It Be\nSINGER The Beatles\n");
        fprintf(file, "ID 15\nNAME Love Me Like You Do\nSINGER Ellie Goulding\n");

        fclose(file);
        file = fopen("song_library.txt", "r");
    }

    struct SongLibrary *lib = create_library();
    char line[256];

    int temp_id = 0;
    char temp_name[100] = "", temp_singer[100] = "";

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0';

        if (strncmp(line, "ID ", 3) == 0) {
            sscanf(line + 3, "%d", &temp_id);
        } else if (strncmp(line, "NAME ", 5) == 0) {
            strcpy(temp_name, line + 5);
        } else if (strncmp(line, "SINGER ", 7) == 0) {
            strcpy(temp_singer, line + 7);

            // Add complete song to library
            add_to_library(lib, temp_id, temp_name, temp_singer);

            if (temp_id >= next_library_song_id)
                next_library_song_id = temp_id + 1;
        }
    }

    fclose(file);
    printf("Song library loaded successfully!\n");
    return lib;
}

void free_library(struct SongLibrary *lib) {
    struct Song *temp;
    while (lib->head != NULL) {
        temp = lib->head;
        lib->head = lib->head->next;
        free(temp);
    }
    free(lib);
}